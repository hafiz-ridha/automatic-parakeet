#!/bin/sh
set -e

# Bind mounts are often root-owned on the host; the app runs as gowauser and SQLite
# needs write access (DB + WAL). Fix ownership at start (requires container root).
for d in /app/storages /app/statics /app/statics/qrcode /app/statics/senditems /app/statics/media; do
	[ -d "$d" ] || mkdir -p "$d"
	chown -R gowauser:gowa "$d" 2>/dev/null || true
done

# Default AI_REPLY_ENABLED to "true" supaya dashboard's /aireply/* tab works
# out-of-the-box. User dapat override eksplisit lewat src/.env atau
# compose environment kalau memang mau matikan.
: "${AI_REPLY_ENABLED:=true}"
export AI_REPLY_ENABLED

# Auto-generate AI_ENCRYPTION_KEY (AES-GCM, 32-byte hex / 64 char) on first
# start kalau AI Reply aktif tapi key belum ada. Simpan di storages volume
# supaya stable across container rebuild. Tanpa ini, user dapat 404 di
# dashboard AI Reply tab atau panic saat core boot.
#
# PERHATIKAN: kalau file ini hilang/terhapus, semua API key provider yang
# tersimpan terenkripsi di SQLite jadi unreadable. Backup terpisah!
if [ "${AI_REPLY_ENABLED}" = "true" ] && [ -z "${AI_ENCRYPTION_KEY:-}" ]; then
	KEYFILE="/app/storages/.ai-encryption-key"
	if [ -f "${KEYFILE}" ]; then
		AI_ENCRYPTION_KEY="$(cat "${KEYFILE}")"
		echo "[entrypoint] Loaded AI_ENCRYPTION_KEY from ${KEYFILE}"
	else
		AI_ENCRYPTION_KEY="$(head -c 32 /dev/urandom | od -An -vtx1 | tr -d ' \n')"
		printf "%s" "${AI_ENCRYPTION_KEY}" > "${KEYFILE}"
		chmod 600 "${KEYFILE}"
		chown gowauser:gowa "${KEYFILE}" 2>/dev/null || true
		echo "[entrypoint] Generated new AI_ENCRYPTION_KEY -> ${KEYFILE}"
		echo "[entrypoint] !! BACKUP KEYFILE !! Losing it = all stored provider API keys become unreadable."
	fi
	export AI_ENCRYPTION_KEY
fi

exec su-exec gowauser /app/whatsapp "$@"
