---
description: Update Github Release Note
---

Use Github CLI to update the release note description. you have to follow previouse release note style.