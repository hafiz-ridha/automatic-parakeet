package chatstorage

import "time"

// Chat represents a WhatsApp chat/conversation
type Chat struct {
	DeviceID            string    `db:"device_id"`
	JID                 string    `db:"jid"`
	Name                string    `db:"name"`
	LastMessageTime     time.Time `db:"last_message_time"`
	EphemeralExpiration uint32    `db:"ephemeral_expiration"`
	CreatedAt           time.Time `db:"created_at"`
	UpdatedAt           time.Time `db:"updated_at"`
	Archived            bool      `db:"archived"`
}

// Message represents a WhatsApp message
type Message struct {
	ID               string    `db:"id"`
	ChatJID          string    `db:"chat_jid"`
	DeviceID         string    `db:"device_id"`
	Sender           string    `db:"sender"`
	Content          string    `db:"content"`
	Timestamp        time.Time `db:"timestamp"`
	IsFromMe         bool      `db:"is_from_me"`
	MediaType        string    `db:"media_type"`
	CallMetadata     string    `db:"call_metadata"`
	Filename         string    `db:"filename"`
	URL              string    `db:"url"`
	MediaKey         []byte    `db:"media_key"`
	FileSHA256       []byte    `db:"file_sha256"`
	FileEncSHA256    []byte    `db:"file_enc_sha256"`
	FileLength       uint64    `db:"file_length"`
	ReferralMetadata string    `db:"referral_metadata"`
	CreatedAt        time.Time `db:"created_at"`
	UpdatedAt        time.Time `db:"updated_at"`
}

// MediaInfo represents downloadable media information
type MediaInfo struct {
	MessageID     string
	ChatJID       string
	MediaType     string
	Filename      string
	URL           string
	MediaKey      []byte
	FileSHA256    []byte
	FileEncSHA256 []byte
	FileLength    uint64
}

// DeviceRecord tracks a registered device for persistence purposes.
type DeviceRecord struct {
	DeviceID    string    `db:"device_id"`
	DisplayName string    `db:"display_name"`
	JID         string    `db:"jid"`
	CreatedAt   time.Time `db:"created_at"`
	UpdatedAt   time.Time `db:"updated_at"`
}

// MessageFilter represents query filters for messages
type MessageFilter struct {
	DeviceID  string
	ChatJID   string
	Limit     int
	Offset    int
	StartTime *time.Time
	EndTime   *time.Time
	MediaOnly bool
	IsFromMe  *bool
}

// ChatFilter represents query filters for chats
type ChatFilter struct {
	DeviceID   string
	Limit      int
	Offset     int
	SearchName string
	HasMedia   bool
	IsArchived *bool
}
